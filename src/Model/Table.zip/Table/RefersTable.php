<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Auth\DefaultPasswordHasher;

class RefersTable extends Table {

    public $name = 'refers';
	
    
				
	    
	 


}
?>
