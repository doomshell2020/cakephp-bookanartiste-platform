<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Auth\DefaultPasswordHasher;

class SitesettingsTable extends Table {

    public $name = 'Sitesettings';
	
    
				
	    
	 


}
?>
